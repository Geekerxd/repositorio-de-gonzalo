//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por Project1.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     103
#define IDD_DIALOG3                     105
#define IDR_MENU1                       107
#define IDC_EDIT1                       1001
#define IDC_DATETIMEPICKER1             1003
#define IDC_DATETIMEPICKER2             1004
#define IDC_COMBO1                      1005
#define IDC_LIST1                       1006
#define IDC_CMB_SPC                     1007
#define ID_VER_MODAL                    40001
#define ID_VER_NOMODAL                  40002
#define ID_Menu                         40003
#define ID_CITAS_NUEVA                  40004
#define ID_CITAS_VER                    40005
#define ID_ARCHIVO_SALIR                40006
#define ID_EDITAR_QUESEYO               40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
