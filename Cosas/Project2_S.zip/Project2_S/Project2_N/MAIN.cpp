#include <fstream>
#include <Windows.h>
#include "resource.h"

using namespace std;

HWND ghDlg = 0;
HINSTANCE _hInst;
int _show = 0;
char _arch_esp[] = "spc.txt";

BOOL CALLBACK ProcDialog1(HWND Dlg, UINT Mensaje, WPARAM wParam, LPARAM lparam);
BOOL CALLBACK ProcDialog2(HWND Dlg, UINT Mensaje, WPARAM wParam, LPARAM lparam); 
BOOL CALLBACK ProcDialog3(HWND Dlg, UINT Mensaje, WPARAM wParam, LPARAM lparam);

void LlenaEspecies(HWND objeto, UINT mensa, char *file);

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, PSTR cmd, int show)
{
	_hInst = hInst;
	_show = show;
	ghDlg = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG1),
		0, ProcDialog1);
	ShowWindow(ghDlg, show);
	MSG msg;
	ZeroMemory(&msg, sizeof(MSG));
	while (GetMessage(&msg, 0, 0, 0))
	{
		if (ghDlg == 0 || !IsDialogMessage(ghDlg, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return (int)msg.wParam;
}


BOOL CALLBACK ProcDialog1(HWND Dlg, UINT Mensaje, WPARAM wParam, LPARAM lparam)
{
	char cliente[20] = "";
	static HWND hCte = 0;

	switch (Mensaje)
	{
	case WM_INITDIALOG:
	{
		hCte = GetDlgItem(Dlg, IDC_EDIT1);
		
		return true; }
	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case IDOK:
			//SendMessage(hCte, WM_GETTEXT, 20, (LPARAM)cliente);

			GetWindowText(hCte, cliente, 20);

			MessageBox(Dlg, cliente, "Cecy", MB_OK);

			return true;
		case ID_VER_MODAL:
			DialogBox(_hInst, MAKEINTRESOURCE(IDD_DIALOG2), Dlg, ProcDialog2);
			return true;
		case ID_VER_NOMODAL:
			HWND Dialg = CreateDialog(_hInst, MAKEINTRESOURCE(IDD_DIALOG3), Dlg, ProcDialog3);

			ShowWindow(Dialg, _show);

			return true;

		}
		return true; }
	case WM_CLOSE:
	{
		PostQuitMessage(0);
		return true; }
	case WM_DESTROY:
	{return true; }
	}
	return false;
}

BOOL CALLBACK ProcDialog2(HWND Dlg, UINT Mensaje, WPARAM wParam, LPARAM lparam)
{
	char cliente[20] = "";
	static HWND hCte = 0;

	switch (Mensaje)
	{
	case WM_INITDIALOG:
	{
		hCte = GetDlgItem(Dlg, IDC_EDIT1);
		SendDlgItemMessage(Dlg, IDC_LIST1, LB_RESETCONTENT, 0, 0);
		LlenaEspecies(GetDlgItem(Dlg, IDC_LIST1), LB_ADDSTRING, _arch_esp);

		return true; }
	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case IDOK:

			EndDialog(Dlg, 0);

			return true;

		}
	

		return true; }
	case WM_CLOSE:
	{
		return true; }
	case WM_DESTROY:
	{return true; }
	}
	return false;
}

BOOL CALLBACK ProcDialog3(HWND Dlg, UINT Mensaje, WPARAM wParam, LPARAM lparam)
{
	char cliente[20] = "";
	static HWND hCboSpc = 0;

	switch (Mensaje)
	{
	case WM_INITDIALOG:
	{
		hCboSpc = GetDlgItem(Dlg, IDC_CMB_SPC);
		/*
		SendMessage(hCboSpc, CB_ADDSTRING, 0, (LPARAM)"BOA");
		SendMessage(hCboSpc, CB_ADDSTRING, 0, (LPARAM)"PITON");
		SendMessage(hCboSpc, CB_ADDSTRING, 0, (LPARAM)"ANACONDA");
		*/
		LlenaEspecies(hCboSpc, CB_ADDSTRING, _arch_esp);


		return true; }
	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case IDOK:
			DestroyWindow(Dlg);

			return true;
		case IDCANCEL:
			PostQuitMessage(0);
			return true;
		case IDC_CMB_SPC:
		{
			if (HIWORD(wParam) == CBN_CLOSEUP)
			{
				MessageBox(Dlg, "SE CERRO", "SI", MB_OKCANCEL);
			}
			if (HIWORD(wParam) == CBN_KILLFOCUS)
			{
				MessageBox(Dlg, "SE FUE EL FOCO", "SI SE FUE", MB_YESNOCANCEL);
			}

			return true;
		}
		}
		return true; }
	case WM_CLOSE:
	{
		return true; }
	case WM_DESTROY:
	{return true; }
	}
	return false;
}

void LlenaEspecies(HWND objeto, UINT mensa, char *file)
{
	ifstream archi;
	char row[30] = "";
	archi.open(file);
	if (archi.is_open())
	{
		archi.getline(row, 30);
		while (!archi.eof())
		{
			SendMessage(objeto, mensa, 0, (LPARAM)row);
			archi.getline(row, 30);
		}

		archi.close();
	}

}