//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por Project1.rc
//
#define IDC_ADD                         3
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     103
#define IDD_DIALOG3                     105
#define IDR_MENU1                       107
#define IDC_EDIT1                       1001
#define IDC_DATETIMEPICKER1             1003
#define IDC_DATETIMEPICKER2             1004
#define IDC_COMBO1                      1005
#define IDC_LIST1                       1006
#define IDC_ESPECIE                     1007
#define IDC_NOMBRE                      1008
#define IDC_FECHA                       1009
#define IDC_HORA                        1010
#define IDC_URGENT                      1011
#define IDC_RADIO1                      1012
#define IDC_RADIO2                      1013
#define IDC_CHECK1                      1013
#define IDC_CHECK2                      1014
#define IDC_CHECK3                      1015
#define IDC_CHECK4                      1016
#define IDC_CHECK5                      1017
#define ID_VER_MODAL                    40001
#define ID_VER_NOMODAL                  40002
#define ID_Menu                         40003
#define ID_CITAS_NUEVA                  40004
#define ID_CITAS_VER                    40005
#define ID_ARCHIVO_SALIR                40006
#define ID_EDITAR_QUESEYO               40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
